<?php
/**
 * FIX TEMPORAL - Error 400 en admin-ajax.php
 * 
 * Añade este código al FINAL de tu functions.php
 * ELIMÍNALO después de solucionar el problema
 * 
 * Este fix intercepta las llamadas AJAX incorrectas y las redirige a REST API
 */

add_action('admin_footer', function() {
    $screen = get_current_screen();
    if (!$screen || $screen->id !== 'toplevel_page_baseo-custom-schema') {
        return;
    }
    ?>
    <script>
    jQuery(document).ready(function($) {
        console.log('[FIX] Aplicando fix para error 400...');
        
        // Sobrescribir loadBulkUrls para usar REST API correctamente
        if (window.BASEO && typeof window.BASEO.loadBulkUrls === 'function') {
            const originalLoadBulkUrls = window.BASEO.loadBulkUrls;
            
            window.BASEO.loadBulkUrls = function() {
                console.log('[FIX] Interceptando loadBulkUrls...');
                
                // Obtener todas las URLs únicas de los schemas
                var apiUrl = baseo_ajax.rest_base + '/schemas/urls';
                
                $('#baseo-bulk-urls-container').html(
                    '<div class="baseo-loading">' +
                    '<div class="baseo-spinner"></div>' +
                    '<p>Cargando URLs...</p>' +
                    '</div>'
                );
                
                $.ajax({
                    url: apiUrl,
                    method: 'GET',
                    beforeSend: function(xhr) {
                        xhr.setRequestHeader('X-WP-Nonce', baseo_ajax.rest_nonce);
                    },
                    success: function(data) {
                        console.log('[FIX] URLs cargadas correctamente:', data);
                        
                        if (!data || data.length === 0) {
                            $('#baseo-bulk-urls-container').html(
                                '<div class="baseo-empty-state">' +
                                '<p>🌟 No hay URLs con schemas todavía</p>' +
                                '</div>'
                            );
                            return;
                        }
                        
                        // Renderizar URLs
                        var html = '<div class="baseo-urls-list">';
                        
                        data.forEach(function(urlData) {
                            html += '<div class="baseo-url-item">';
                            html += '<div class="baseo-url-info">';
                            html += '<span class="baseo-url-text">' + urlData.url + '</span>';
                            html += '<span class="baseo-url-count">' + urlData.count + ' schemas</span>';
                            html += '</div>';
                            html += '<div class="baseo-url-actions">';
                            html += '<button class="baseo-btn-small baseo-view-url-schemas" data-url="' + urlData.url + '">Ver Schemas</button>';
                            html += '</div>';
                            html += '</div>';
                        });
                        
                        html += '</div>';
                        $('#baseo-bulk-urls-container').html(html);
                    },
                    error: function(xhr) {
                        console.error('[FIX] Error cargando URLs:', xhr);
                        
                        // Fallback: Usar loadSchemas directamente
                        console.log('[FIX] Usando fallback - loadSchemas...');
                        if (window.BASEO.loadSchemas) {
                            window.BASEO.loadSchemas(1, true);
                        }
                    }
                });
            };
            
            console.log('[FIX] loadBulkUrls sobrescrito correctamente');
        }
        
        // Sobrescribir loadSchemas si tiene problemas también
        if (window.BASEO && typeof window.BASEO.loadSchemas === 'function') {
            const originalLoadSchemas = window.BASEO.loadSchemas;
            
            window.BASEO.loadSchemas = function(page, resetFilter, isRetry) {
                page = page || 1;
                resetFilter = resetFilter || false;
                isRetry = isRetry || false;
                
                console.log('[FIX] loadSchemas llamado - página:', page);
                
                // Asegurarse de usar REST API, no admin-ajax.php
                var apiUrl = baseo_ajax.rest_base + '/schemas';
                apiUrl += '?page=' + page;
                
                var currentPerPage = 20;
                if (window.BASEO.state && window.BASEO.state.currentPerPage) {
                    currentPerPage = window.BASEO.state.currentPerPage;
                }
                apiUrl += '&per_page=' + currentPerPage;
                
                if (window.BASEO.state && window.BASEO.state.currentSchemaType) {
                    apiUrl += '&schema_type=' + encodeURIComponent(window.BASEO.state.currentSchemaType);
                }
                
                if (window.BASEO.state && window.BASEO.state.currentSearchQuery) {
                    apiUrl += '&search=' + encodeURIComponent(window.BASEO.state.currentSearchQuery);
                }
                
                $('#baseo-schemas-container').html(
                    '<div class="baseo-loading">' +
                    '<div class="baseo-spinner"></div>' +
                    '<p>Cargando schemas...</p>' +
                    '</div>'
                );
                
                $.ajax({
                    url: apiUrl,
                    method: 'GET',
                    beforeSend: function(xhr) {
                        xhr.setRequestHeader('X-WP-Nonce', baseo_ajax.rest_nonce);
                    },
                    success: function(data, textStatus, xhr) {
                        console.log('[FIX] Schemas cargados:', data);
                        
                        var totalItems = parseInt(xhr.getResponseHeader('X-WP-Total')) || 0;
                        var totalPages = parseInt(xhr.getResponseHeader('X-WP-TotalPages')) || 1;
                        
                        if (window.BASEO.displaySchemasWithPagination) {
                            window.BASEO.displaySchemasWithPagination(data, totalItems, totalPages);
                        } else {
                            console.error('[FIX] displaySchemasWithPagination no está disponible');
                        }
                    },
                    error: function(xhr) {
                        console.error('[FIX] Error cargando schemas:', xhr);
                        
                        var errorMsg = 'Error cargando schemas';
                        if (xhr.responseJSON && xhr.responseJSON.message) {
                            errorMsg += ': ' + xhr.responseJSON.message;
                        }
                        
                        $('#baseo-schemas-container').html(
                            '<div class="baseo-error-state">' +
                            '<p>❌ ' + errorMsg + '</p>' +
                            '<p>Código de error: ' + xhr.status + '</p>' +
                            '</div>'
                        );
                    }
                });
            };
            
            console.log('[FIX] loadSchemas sobrescrito correctamente');
        }
        
        console.log('[FIX] Fix aplicado completamente');
    });
    </script>
    <?php
}, 9999);