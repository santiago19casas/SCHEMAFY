<?php
/**
 * ENDPOINT ADICIONAL - GET /schemas/urls
 * 
 * Añade este código al FINAL de functions.php TEMPORALMENTE
 * Este endpoint devuelve todas las URLs únicas con sus conteos de schemas
 */

add_action('rest_api_init', function() {
    register_rest_route('baseo/v1', '/schemas/urls', array(
        'methods' => 'GET',
        'callback' => 'baseo_get_unique_urls',
        'permission_callback' => function() {
            return current_user_can('manage_options');
        }
    ));
});

function baseo_get_unique_urls($request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'baseo_custom_schemas';
    
    // Obtener URLs únicas con conteo de schemas
    $results = $wpdb->get_results("
        SELECT 
            url,
            COUNT(*) as count,
            SUM(CASE WHEN is_active = 1 THEN 1 ELSE 0 END) as active_count
        FROM {$table_name}
        GROUP BY url
        ORDER BY url ASC
    ");
    
    if ($wpdb->last_error) {
        return new WP_Error(
            'database_error',
            'Error al consultar la base de datos: ' . $wpdb->last_error,
            array('status' => 500)
        );
    }
    
    // Formatear resultados
    $formatted = array();
    foreach ($results as $row) {
        $formatted[] = array(
            'url' => $row->url,
            'count' => (int) $row->count,
            'active_count' => (int) $row->active_count
        );
    }
    
    return rest_ensure_response($formatted);
}