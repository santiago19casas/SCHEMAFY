<?php
/**
 * BASEO Meta Box Class
 * 
 * Handles meta boxes in the WordPress post/page editor
 * 
 * @package CustomSchemaBaseo
 * @since 1.1.85
 * @author BASEO Team
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit(__('Direct access not allowed!', 'custom-schema-baseo'));
}

/**
 * Class BASEO_Meta_Box
 * 
 * Manages meta box for SEO meta tags in post editor
 */
class BASEO_Meta_Box {
    
    /**
     * Validator instance
     * 
     * @var BASEO_Validator
     */
    private $validator;
    
    /**
     * Database instance
     * 
     * @var BASEO_Database
     */
    private $database;
    
    /**
     * Constructor
     * 
     * @param BASEO_Validator $validator Validator instance
     * @param BASEO_Database $database Database instance
     */
    public function __construct($validator, $database) {
        $this->validator = $validator;
        $this->database = $database;
        
        add_action('add_meta_boxes', array($this, 'add_meta_box'));
        add_action('save_post', array($this, 'save_meta_box'));
    }
    
    /**
     * Add meta box to post types
     * 
     * @return void
     */
    public function add_meta_box() {
        $post_types = array('post', 'page', 'product');
        
        foreach ($post_types as $post_type) {
            add_meta_box(
                'baseo_schema_meta',
                __('SEO Meta Tags (BASEO)', 'custom-schema-baseo'),
                array($this, 'render_meta_box'),
                $post_type,
                'side',
                'high'
            );
        }
    }
    
    /**
     * Render meta box content
     * 
     * @param WP_Post $post Current post object
     * @return void
     */
    public function render_meta_box($post) {
        // Add nonce field for security
        wp_nonce_field('baseo_meta_box', 'baseo_meta_box_nonce');
        
        // Get current values
        $meta_title = get_post_meta($post->ID, '_baseo_meta_title', true);
        $meta_description = get_post_meta($post->ID, '_baseo_meta_description', true);
        
        ?>
        <div class="baseo-meta-box-wrapper">
            <p>
                <label for="baseo_meta_title">
                    <strong><?php _e('Meta Title:', 'custom-schema-baseo'); ?></strong>
                </label>
                <input 
                    type="text" 
                    id="baseo_meta_title" 
                    name="baseo_meta_title" 
                    value="<?php echo esc_attr($meta_title); ?>" 
                    style="width: 100%;" 
                    maxlength="70"
                    placeholder="<?php esc_attr_e('Leave empty to use default', 'custom-schema-baseo'); ?>"
                />
                <span class="description">
                    <?php _e('Optimal: 50-60 characters', 'custom-schema-baseo'); ?>
                </span>
            </p>
            
            <p>
                <label for="baseo_meta_description">
                    <strong><?php _e('Meta Description:', 'custom-schema-baseo'); ?></strong>
                </label>
                <textarea 
                    id="baseo_meta_description" 
                    name="baseo_meta_description" 
                    rows="3" 
                    style="width: 100%;" 
                    maxlength="160"
                    placeholder="<?php esc_attr_e('Leave empty to use default', 'custom-schema-baseo'); ?>"
                ><?php echo esc_textarea($meta_description); ?></textarea>
                <span class="description">
                    <?php _e('Optimal: 150-160 characters', 'custom-schema-baseo'); ?>
                </span>
            </p>
            
            <p class="description">
                <?php _e('These values will be used in schema markup and can override SEO plugin settings.', 'custom-schema-baseo'); ?>
            </p>
        </div>
        
        <style>
            .baseo-meta-box-wrapper {
                padding: 10px 0;
            }
            .baseo-meta-box-wrapper label {
                display: block;
                margin-bottom: 5px;
            }
            .baseo-meta-box-wrapper input,
            .baseo-meta-box-wrapper textarea {
                margin-bottom: 5px;
            }
            .baseo-meta-box-wrapper .description {
                display: block;
                font-size: 12px;
                color: #666;
                font-style: italic;
                margin-bottom: 10px;
            }
        </style>
        <?php
    }
    
    /**
     * Save meta box data
     * 
     * @param int $post_id Post ID
     * @return void
     */
    public function save_meta_box($post_id) {
        // Security checks
        if (!isset($_POST['baseo_meta_box_nonce']) || 
            !wp_verify_nonce($_POST['baseo_meta_box_nonce'], 'baseo_meta_box')) {
            return;
        }
        
        // Check if this is an autosave
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        // Check user permissions
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        
        // Save meta_title
        if (isset($_POST['baseo_meta_title'])) {
            $meta_title = sanitize_text_field($_POST['baseo_meta_title']);
            update_post_meta($post_id, '_baseo_meta_title', $meta_title);
        }
        
        // Save meta_description
        if (isset($_POST['baseo_meta_description'])) {
            $meta_description = sanitize_textarea_field($_POST['baseo_meta_description']);
            update_post_meta($post_id, '_baseo_meta_description', $meta_description);
        }
        
        // Sync to schemas table if needed
        $this->sync_to_schemas_table($post_id, $_POST['baseo_meta_title'] ?? '', $_POST['baseo_meta_description'] ?? '');
    }
    
    /**
     * Sync meta data to schemas table
     * Updates any schemas associated with this post's URL
     * 
     * @param int $post_id Post ID
     * @param string $meta_title Meta title
     * @param string $meta_description Meta description
     * @return void
     */
    private function sync_to_schemas_table($post_id, $meta_title, $meta_description) {
        // Get post URL
        $post_url = get_permalink($post_id);
        
        if (!$post_url) {
            return;
        }
        
        // Update schemas table
        $this->database->update_meta_by_url($post_url, $meta_title, $meta_description);
    }
}