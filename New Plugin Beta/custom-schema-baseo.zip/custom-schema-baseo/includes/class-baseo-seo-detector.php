<?php
/**
 * BASEO SEO Detector Class
 * 
 * Handles detection of meta title and description from various SEO plugins
 * 
 * @package CustomSchemaBaseo
 * @since 1.1.85
 * @author BASEO Team
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit(__('Direct access not allowed!', 'custom-schema-baseo'));
}

/**
 * Class BASEO_SEO_Detector
 * 
 * Detects and retrieves meta title and description from all major SEO plugins
 */
class BASEO_SEO_Detector {
    
    /**
     * Validator instance
     * 
     * @var BASEO_Validator
     */
    private $validator;
    
    /**
     * Constructor
     * 
     * @param BASEO_Validator $validator Validator instance
     */
    public function __construct($validator) {
        $this->validator = $validator;
    }
    
    /**
     * Get meta title with cascading detection
     * 
     * @param int $post_id Post ID
     * @param string $url Current URL
     * @return string Meta title
     */
    public function get_meta_title($post_id, $url) {
        $meta_title = '';
        
        // 1A: Try BASEO custom meta first
        if ($post_id > 0) {
            $meta_title = get_post_meta($post_id, '_baseo_meta_title', true);
        }
        
        // 1B: If empty, try Yoast SEO
        if (empty($meta_title)) {
            $meta_title = $this->detect_yoast_title($post_id);
        }
        
        // 1C: If empty, try Rank Math
        if (empty($meta_title)) {
            $meta_title = $this->detect_rankmath_title($post_id);
        }
        
        // 1D: If empty, try All in One SEO
        if (empty($meta_title)) {
            $meta_title = $this->detect_aioseo_title($post_id);
        }
        
        // 1E: If empty, try SEOPress
        if (empty($meta_title)) {
            $meta_title = $this->detect_seopress_title($post_id);
        }
        
        // 1F: If empty, try The SEO Framework
        if (empty($meta_title)) {
            $meta_title = $this->detect_seo_framework_title($post_id);
        }
        
        // 1G: Fallback to WordPress defaults
        if (empty($meta_title)) {
            $meta_title = $this->get_wordpress_default_title($post_id);
        }
        
        // 1H: Fallback to BASEO table
        if (empty($meta_title)) {
            $meta_title = $this->get_baseo_fallback_title($url);
        }
        
        // 1I: Process SEO variables
        if (!empty($meta_title)) {
            $meta_title = $this->process_seo_variables($meta_title, $post_id);
        }
        
        return $meta_title;
    }
    
    /**
     * Get meta description with cascading detection
     * 
     * @param int $post_id Post ID
     * @param string $url Current URL
     * @return string Meta description
     */
    public function get_meta_description($post_id, $url) {
        $meta_description = '';
        
        // 1A: Try BASEO custom meta first
        if ($post_id > 0) {
            $meta_description = get_post_meta($post_id, '_baseo_meta_description', true);
        }
        
        // 1B: If empty, try Yoast SEO
        if (empty($meta_description)) {
            $meta_description = $this->detect_yoast_description($post_id);
        }
        
        // 1C: If empty, try Rank Math
        if (empty($meta_description)) {
            $meta_description = $this->detect_rankmath_description($post_id);
        }
        
        // 1D: If empty, try All in One SEO
        if (empty($meta_description)) {
            $meta_description = $this->detect_aioseo_description($post_id);
        }
        
        // 1E: If empty, try SEOPress
        if (empty($meta_description)) {
            $meta_description = $this->detect_seopress_description($post_id);
        }
        
        // 1F: If empty, try The SEO Framework
        if (empty($meta_description)) {
            $meta_description = $this->detect_seo_framework_description($post_id);
        }
        
        // 1G: Fallback to WordPress defaults
        if (empty($meta_description)) {
            $meta_description = $this->get_wordpress_default_description($post_id);
        }
        
        // 1H: Fallback to BASEO table
        if (empty($meta_description)) {
            $meta_description = $this->get_baseo_fallback_description($url);
        }
        
        // 1I: Process SEO variables
        if (!empty($meta_description)) {
            $meta_description = $this->process_seo_variables($meta_description, $post_id);
        }
        
        return $meta_description;
    }
    
    /**
     * Detect Yoast SEO title
     * 
     * @param int $post_id Post ID
     * @return string Title or empty string
     */
    private function detect_yoast_title($post_id) {
        if ($post_id > 0 && defined('WPSEO_VERSION')) {
            return get_post_meta($post_id, '_yoast_wpseo_title', true);
        }
        return '';
    }
    
    /**
     * Detect Yoast SEO description
     * 
     * @param int $post_id Post ID
     * @return string Description or empty string
     */
    private function detect_yoast_description($post_id) {
        if ($post_id > 0 && defined('WPSEO_VERSION')) {
            return get_post_meta($post_id, '_yoast_wpseo_metadesc', true);
        }
        return '';
    }
    
    /**
     * Detect Rank Math title
     * 
     * @param int $post_id Post ID
     * @return string Title or empty string
     */
    private function detect_rankmath_title($post_id) {
        if ($post_id > 0 && class_exists('RankMath')) {
            return get_post_meta($post_id, 'rank_math_title', true);
        }
        return '';
    }
    
    /**
     * Detect Rank Math description
     * 
     * @param int $post_id Post ID
     * @return string Description or empty string
     */
    private function detect_rankmath_description($post_id) {
        if ($post_id > 0 && class_exists('RankMath')) {
            return get_post_meta($post_id, 'rank_math_description', true);
        }
        return '';
    }
    
    /**
     * Detect All in One SEO title
     * 
     * @param int $post_id Post ID
     * @return string Title or empty string
     */
    private function detect_aioseo_title($post_id) {
        if ($post_id > 0 && function_exists('aioseo')) {
            $title = get_post_meta($post_id, '_aioseo_title', true);
            if (!empty($title)) {
                return $title;
            }
        }
        return '';
    }
    
    /**
     * Detect All in One SEO description
     * 
     * @param int $post_id Post ID
     * @return string Description or empty string
     */
    private function detect_aioseo_description($post_id) {
        if ($post_id > 0 && function_exists('aioseo')) {
            $description = get_post_meta($post_id, '_aioseo_description', true);
            if (!empty($description)) {
                return $description;
            }
        }
        return '';
    }
    
    /**
     * Detect SEOPress title
     * 
     * @param int $post_id Post ID
     * @return string Title or empty string
     */
    private function detect_seopress_title($post_id) {
        if ($post_id > 0 && function_exists('seopress_titles_the_title')) {
            return get_post_meta($post_id, '_seopress_titles_title', true);
        }
        return '';
    }
    
    /**
     * Detect SEOPress description
     * 
     * @param int $post_id Post ID
     * @return string Description or empty string
     */
    private function detect_seopress_description($post_id) {
        if ($post_id > 0 && function_exists('seopress_titles_the_title')) {
            return get_post_meta($post_id, '_seopress_titles_desc', true);
        }
        return '';
    }
    
    /**
     * Detect Slim SEO title
     * 
     * @param int $post_id Post ID
     * @return string Title or empty string
     */
    private function detect_slim_seo_title($post_id) {
        if ($post_id > 0 && function_exists('slim_seo')) {
            return get_post_meta($post_id, 'slim_seo_title', true);
        }
        return '';
    }
    
    /**
     * Detect Slim SEO description
     * 
     * @param int $post_id Post ID
     * @return string Description or empty string
     */
    private function detect_slim_seo_description($post_id) {
        if ($post_id > 0 && function_exists('slim_seo')) {
            return get_post_meta($post_id, 'slim_seo_description', true);
        }
        return '';
    }
    
    /**
     * Detect The SEO Framework title
     * 
     * @param int $post_id Post ID
     * @return string Title or empty string
     */
    private function detect_seo_framework_title($post_id) {
        if ($post_id > 0 && function_exists('the_seo_framework')) {
            $tsf = the_seo_framework();
            if (method_exists($tsf, 'get_custom_field')) {
                return $tsf->get_custom_field('_genesis_title', $post_id);
            }
        }
        return '';
    }
    
    /**
     * Detect The SEO Framework description
     * 
     * @param int $post_id Post ID
     * @return string Description or empty string
     */
    private function detect_seo_framework_description($post_id) {
        if ($post_id > 0 && function_exists('the_seo_framework')) {
            $tsf = the_seo_framework();
            if (method_exists($tsf, 'get_custom_field')) {
                return $tsf->get_custom_field('_genesis_description', $post_id);
            }
        }
        return '';
    }
    
    /**
     * Get WordPress default title
     * 
     * @param int $post_id Post ID
     * @return string Title or empty string
     */
    private function get_wordpress_default_title($post_id) {
        if ($post_id > 0) {
            return get_the_title($post_id);
        }
        return '';
    }
    
    /**
     * Get WordPress default description
     * 
     * @param int $post_id Post ID
     * @return string Description or empty string
     */
    private function get_wordpress_default_description($post_id) {
        if ($post_id > 0) {
            $description = get_the_excerpt($post_id);
            if (empty($description)) {
                $post_content = get_post_field('post_content', $post_id);
                $description = wp_trim_words(strip_tags($post_content), 30, '...');
            }
            return $description;
        }
        return '';
    }
    
    /**
     * Get fallback title from BASEO table
     * 
     * @param string $url Current URL
     * @return string Title or empty string
     */
    private function get_baseo_fallback_title($url) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'baseo_custom_schemas';
        
        $meta = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_title FROM $table_name 
             WHERE url = %s AND is_active = 1 AND meta_title IS NOT NULL AND meta_title != ''
             ORDER BY updated_at DESC LIMIT 1",
            $url
        ));
        
        return $meta ? $meta : '';
    }
    
    /**
     * Get fallback description from BASEO table
     * 
     * @param string $url Current URL
     * @return string Description or empty string
     */
    private function get_baseo_fallback_description($url) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'baseo_custom_schemas';
        
        $meta = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_description FROM $table_name 
             WHERE url = %s AND is_active = 1 AND meta_description IS NOT NULL AND meta_description != ''
             ORDER BY updated_at DESC LIMIT 1",
            $url
        ));
        
        return $meta ? $meta : '';
    }
    
    /**
     * Process SEO plugin variables (Yoast, Rank Math, etc.)
     * 
     * @param string $text Text containing variables
     * @param int $post_id Post ID
     * @return string Processed text
     */
    public function process_seo_variables($text, $post_id = 0) {
        if (empty($text)) {
            return $text;
        }
        
        $post = null;
        if ($post_id > 0) {
            $post = get_post($post_id);
        }
        
        // Common SEO variables
        $replacements = array(
            // Yoast style (double %%)
            '%%title%%' => $post ? get_the_title($post_id) : '',
            '%%sitename%%' => get_bloginfo('name'),
            '%%sitedesc%%' => get_bloginfo('description'),
            '%%sep%%' => '-',
            '%%excerpt%%' => $post ? wp_trim_words(strip_tags($post->post_content), 30) : '',
            
            // Rank Math style (single %)
            '%title%' => $post ? get_the_title($post_id) : '',
            '%sitename%' => get_bloginfo('name'),
            '%sitedesc%' => get_bloginfo('description'),
            '%sep%' => '-',
            '%excerpt%' => $post ? wp_trim_words(strip_tags($post->post_content), 30) : '',
        );
        
        // Replace all variables
        foreach ($replacements as $var => $value) {
            $text = str_replace($var, $value, $text);
        }
        
        return $text;
    }
}