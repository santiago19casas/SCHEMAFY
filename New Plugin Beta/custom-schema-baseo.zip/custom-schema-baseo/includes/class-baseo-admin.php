<?php
/**
 * BASEO Admin Class
 * 
 * Handles all admin area functionality for the Custom Schema by BASEO plugin
 * 
 * @package CustomSchemaBaseo
 * @since 1.1.85
 * @author BASEO Team
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit(__('Direct access not allowed!', 'custom-schema-baseo'));
}

/**
 * Class BASEO_Admin
 * 
 * Manages admin page, scripts, styles, and help tabs
 */
class BASEO_Admin {
    
    /**
     * Validator instance
     * 
     * @var BASEO_Validator
     */
    private $validator;
    
    /**
     * Brand information
     * 
     * @var array
     */
    private $brand = array();
    
    /**
     * Constructor
     * 
     * @param BASEO_Validator $validator Validator instance
     */
    public function __construct($validator) {
        $this->validator = $validator;
        
        // Initialize brand information
        $this->brand = array(
            'name' => 'BASEO',
            'plugin_name' => 'Custom Schema by BASEO',
            'plugin_url' => 'http://thebaseo.com/plugins',
            'author_url' => 'http://thebaseo.com',
            'support_url' => 'http://thebaseo.com/support',
            'docs_url' => 'http://thebaseo.com/docs/custom-schema',
            'color' => '#FF6B35',
            'secondary_color' => '#004E98'
        );
    }
    
    /**
     * Add admin menu
     * 
     * @return void
     */
    public function add_admin_menu() {
        $page = add_menu_page(
            $this->brand['plugin_name'] . ' - ' . __('Control Panel', 'custom-schema-baseo'),
            '🚀 Custom Schema BASEO',
            'manage_options',
            'baseo-custom-schema',
            array($this, 'admin_page'),
            'dashicons-media-code',
            30
        );
        
        // Add contextual help
        add_action('load-' . $page, array($this, 'add_help_tabs'));
    }
    
    /**
     * Render admin page
     * 
     * @return void
     */
    public function admin_page() {
        // Security check
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'custom-schema-baseo'));
        }
        
        // Include the admin template
        $template_path = BASEO_SCHEMA_PLUGIN_PATH . 'templates/admin-page.php';
        if (file_exists($template_path)) {
            include $template_path;
        } else {
            // Fallback: render basic structure if template doesn't exist
            echo '<div class="wrap">';
            echo '<h1>' . esc_html($this->brand['plugin_name']) . '</h1>';
            echo '<div class="notice notice-warning"><p>';
            echo __('Template file not found. Please ensure templates/admin-page.php exists.', 'custom-schema-baseo');
            echo '</p></div>';
            echo '<div id="baseo-schema-app"></div>';
            echo '</div>';
        }
    }
    
    /**
     * Enqueue admin scripts and styles
     * 
     * @param string $hook Current page hook
     * @return void
     */
    public function enqueue_admin_scripts($hook) {
        // Only load on our plugin page
        if ($hook !== 'toplevel_page_baseo-custom-schema') {
            return;
        }
        
        // Enqueue CSS
        wp_enqueue_style(
            'baseo-schema-admin',
            BASEO_SCHEMA_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            BASEO_SCHEMA_VERSION,
            'all'
        );
        
        // Inline CSS for tabs and additional styles
        $custom_css = "
        /* Force new tab styles */
        .baseo-tabs {
            display: flex !important;
            gap: 0 !important;
            border-bottom: 3px solid #e1e5e9 !important;
            margin: 30px 0 40px 0 !important;
            background: linear-gradient(180deg, #ffffff 0%, #f8f9fa 100%) !important;
            border-radius: 12px 12px 0 0 !important;
            overflow: hidden !important;
            box-shadow: 0 2px 12px rgba(0,0,0,0.08) !important;
            padding: 0 !important;
        }
        
        .baseo-tab-btn {
            flex: 1 !important;
            padding: 20px 40px !important;
            border: none !important;
            background: transparent !important;
            cursor: pointer !important;
            font-size: 16px !important;
            font-weight: 600 !important;
            color: #6c757d !important;
            border-bottom: 4px solid transparent !important;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
            position: relative !important;
        }
        
        .baseo-tab-btn:hover {
            color: var(--baseo-primary) !important;
            background: linear-gradient(180deg, rgba(255, 107, 53, 0.05) 0%, rgba(255, 107, 53, 0.1) 100%) !important;
        }
        
        .baseo-tab-btn.active {
            color: var(--baseo-primary) !important;
            border-bottom-color: var(--baseo-primary) !important;
            background: linear-gradient(180deg, rgba(255, 107, 53, 0.08) 0%, rgba(255, 107, 53, 0.12) 100%) !important;
            font-weight: 700 !important;
        }
        
        .baseo-tab-content {
            display: none !important;
        }
        
        .baseo-tab-content.active {
            display: block !important;
        }
        ";
        wp_add_inline_style('baseo-schema-admin', $custom_css);
        
        // Enqueue JavaScript files in correct dependency order
        
        // 1. Utils (base - no dependencies)
        wp_enqueue_script(
            'baseo-schema-utils',
            BASEO_SCHEMA_PLUGIN_URL . 'assets/js/admin-utils.js',
            array('jquery'),
            BASEO_SCHEMA_VERSION,
            true
        );
        
        // 2. Editor (depends on utils)
        wp_enqueue_script(
            'baseo-schema-editor',
            BASEO_SCHEMA_PLUGIN_URL . 'assets/js/admin-editor.js',
            array('jquery', 'baseo-schema-utils'),
            BASEO_SCHEMA_VERSION,
            true
        );
        
        // 3. Forms (depends on utils and editor)
        wp_enqueue_script(
            'baseo-schema-forms',
            BASEO_SCHEMA_PLUGIN_URL . 'assets/js/admin-forms.js',
            array('jquery', 'baseo-schema-utils', 'baseo-schema-editor'),
            BASEO_SCHEMA_VERSION,
            true
        );
        
        // 4. Schemas (depends on utils and editor)
        wp_enqueue_script(
            'baseo-schema-schemas',
            BASEO_SCHEMA_PLUGIN_URL . 'assets/js/admin-schemas.js',
            array('jquery', 'baseo-schema-utils', 'baseo-schema-editor'),
            BASEO_SCHEMA_VERSION,
            true
        );
        
        // 5. Main (depends on ALL previous files)
        wp_enqueue_script(
            'baseo-schema-main',
            BASEO_SCHEMA_PLUGIN_URL . 'assets/js/admin-main.js',
            array('jquery', 'baseo-schema-utils', 'baseo-schema-editor', 'baseo-schema-forms', 'baseo-schema-schemas'),
            BASEO_SCHEMA_VERSION,
            true
        );
        
        // Localize script with ALL necessary variables
        wp_localize_script('baseo-schema-utils', 'baseo_ajax', array(
            // REST API configuration
            'rest_url' => esc_url_raw(rest_url()),
            'rest_base' => esc_url_raw(rest_url('baseo/v1')),
            'rest_nonce' => wp_create_nonce('wp_rest'),
            
            // WordPress configuration
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('baseo_nonce'),
            'site_url' => get_site_url(),
            'admin_url' => admin_url(),
            
            // Plugin information
            'version' => BASEO_SCHEMA_VERSION,
            'plugin_url' => BASEO_SCHEMA_PLUGIN_URL,
            
            // Translations
            'i18n' => $this->get_i18n_strings()
        ));
    }
    
    /**
     * Get internationalization strings
     * 
     * @return array Array of translatable strings
     */
    private function get_i18n_strings() {
        return array(
            'loading_schemas' => __('Loading schemas...', 'custom-schema-baseo'),
            'searching' => __('🔍 Searching...', 'custom-schema-baseo'),
            'no_results' => __('No schemas found', 'custom-schema-baseo'),
            'empty_state' => __('🌟 Add your first schema!', 'custom-schema-baseo'),
            'active_short' => __('active', 'custom-schema-baseo'),
            'updated_label' => __('Updated: ', 'custom-schema-baseo'),
            'visit' => __('🔗 Visit', 'custom-schema-baseo'),
            'add_schema' => __('➕ Add Schema', 'custom-schema-baseo'),
            'edit' => __('✏️ Edit', 'custom-schema-baseo'),
            'delete' => __('🗑️ Delete', 'custom-schema-baseo'),
            'activate' => __('▶️ Activate', 'custom-schema-baseo'),
            'deactivate' => __('⏸️ Deactivate', 'custom-schema-baseo'),
            'test_on_google' => __('🧪 Test', 'custom-schema-baseo'),
            'copy_json' => __('📋 Copy', 'custom-schema-baseo'),
            'save_schema' => __('💾 Save Schema', 'custom-schema-baseo'),
            'update_schema' => __('🔄 Update Schema', 'custom-schema-baseo'),
            'cancel' => __('❌ Cancel', 'custom-schema-baseo'),
            'page_label' => __('Page', 'custom-schema-baseo'),
            'of_label' => __('of', 'custom-schema-baseo'),
            'items_label' => __('items', 'custom-schema-baseo'),
            'prev' => __('← Previous', 'custom-schema-baseo'),
            'next' => __('Next →', 'custom-schema-baseo'),
            'validate' => __('✓ Validate', 'custom-schema-baseo'),
            'valid' => __('✅ Valid', 'custom-schema-baseo'),
            'error' => __('❌ Error', 'custom-schema-baseo'),
            'schema_saved' => __('✅ Schema saved successfully!', 'custom-schema-baseo'),
            'schema_updated' => __('✅ Schema updated successfully!', 'custom-schema-baseo'),
            'schema_deleted' => __('🗑️ Schema deleted successfully', 'custom-schema-baseo'),
            'schema_activated' => __('▶️ Schema activated', 'custom-schema-baseo'),
            'schema_deactivated' => __('⏸️ Schema deactivated', 'custom-schema-baseo'),
            'error_loading' => __('❌ Error loading schemas', 'custom-schema-baseo'),
            'error_deleting' => __('❌ Error deleting schema', 'custom-schema-baseo'),
            'confirm_delete' => __('Are you sure you want to delete this schema?', 'custom-schema-baseo'),
            'invalid_url' => __('⚠️ Invalid URL', 'custom-schema-baseo'),
            'invalid_json' => __('❌ Invalid JSON', 'custom-schema-baseo'),
            'json_valid' => __('✅ JSON valid - Ready to save', 'custom-schema-baseo'),
            'script_tags_detected' => __('🚨 Script tags detected! Please remove <script> tags.', 'custom-schema-baseo'),
            'chars_left' => __('characters left', 'custom-schema-baseo'),
            'got_it' => __('Got it!', 'custom-schema-baseo')
        );
    }
    
    /**
     * Add help tabs to admin page
     * 
     * @return void
     */
    public function add_help_tabs() {
        $screen = get_current_screen();
        
        $screen->add_help_tab(array(
            'id' => 'baseo-schema-overview',
            'title' => '📋 ' . __('Overview', 'custom-schema-baseo'),
            'content' => $this->get_help_content_overview()
        ));
        
        $screen->add_help_tab(array(
            'id' => 'baseo-schema-usage',
            'title' => '🎯 ' . __('How to Use', 'custom-schema-baseo'),
            'content' => $this->get_help_content_usage()
        ));
        
        $screen->set_help_sidebar($this->get_help_sidebar());
    }
    
    /**
     * Get overview help content
     * 
     * @return string HTML content
     */
    private function get_help_content_overview() {
        return '<h4>🎯 ' . __('What does this plugin do?', 'custom-schema-baseo') . '</h4>
                <p><strong>' . $this->brand['plugin_name'] . '</strong> ' . __('allows you to add custom structured data (Schema.org) to any page of your website to improve your search engine rankings.', 'custom-schema-baseo') . '</p>
                <h4>✨ ' . __('Benefits:', 'custom-schema-baseo') . '</h4>
                <ul>
                    <li>🚀 <strong>' . __('Better SEO:', 'custom-schema-baseo') . '</strong> ' . __('Rich snippets in Google', 'custom-schema-baseo') . '</li>
                    <li>🎨 <strong>' . __('Easy to use:', 'custom-schema-baseo') . '</strong> ' . __('Intuitive interface', 'custom-schema-baseo') . '</li>
                    <li>⚡ <strong>' . __('Fast:', 'custom-schema-baseo') . '</strong> ' . __('Optimized for performance', 'custom-schema-baseo') . '</li>
                    <li>🔒 <strong>' . __('Secure:', 'custom-schema-baseo') . '</strong> ' . __('Integrated JSON validation', 'custom-schema-baseo') . '</li>
                </ul>';
    }
    
    /**
     * Get usage help content
     * 
     * @return string HTML content
     */
    private function get_help_content_usage() {
        return '<h4>📋 ' . __('Steps to add a schema:', 'custom-schema-baseo') . '</h4>
                <ol>
                    <li>' . __('Enter the <strong>complete URL</strong> of the page', 'custom-schema-baseo') . '</li>
                    <li>' . __('Select the appropriate <strong>schema type</strong>', 'custom-schema-baseo') . '</li>
                    <li>' . __('Paste your <strong>JSON-LD</strong> code (without script tags)', 'custom-schema-baseo') . '</li>
                    <li>' . __('Click <strong>"Validate"</strong> to verify syntax', 'custom-schema-baseo') . '</li>
                    <li>' . __('Save and <strong>you\'re done!</strong>', 'custom-schema-baseo') . '</li>
                </ol>';
    }
    
    /**
     * Get help sidebar content
     * 
     * @return string HTML content
     */
    private function get_help_sidebar() {
        return '<p><strong>🎯 ' . __('Premium Support', 'custom-schema-baseo') . '</strong></p>
                <p>' . __('Need personalized help?', 'custom-schema-baseo') . '</p>
                <p><a href="' . $this->brand['support_url'] . '" target="_blank" class="button button-primary">' . sprintf(__('Contact %s', 'custom-schema-baseo'), $this->brand['name']) . '</a></p>
                <hr>
                <p><strong>📚 ' . __('Documentation', 'custom-schema-baseo') . '</strong></p>
                <p><a href="' . $this->brand['docs_url'] . '" target="_blank">' . __('View complete guides', 'custom-schema-baseo') . '</a></p>';
    }
    
    /**
     * Add custom links in plugins page
     * 
     * @param array $links Existing links
     * @return array Modified links
     */
    public function add_plugin_links($links) {
        $custom_links = array(
            '<a href="' . admin_url('admin.php?page=baseo-custom-schema') . '" style="color: ' . $this->brand['color'] . '; font-weight: bold;">⚙️ ' . __('Configure', 'custom-schema-baseo') . '</a>',
            '<a href="' . $this->brand['docs_url'] . '" target="_blank" style="color: ' . $this->brand['secondary_color'] . ';">📚 ' . __('Documentation', 'custom-schema-baseo') . '</a>'
        );
        return array_merge($custom_links, $links);
    }
    
    /**
     * Add custom metadata in plugins page
     * 
     * @param array $plugin_meta Existing meta
     * @param string $plugin_file Plugin file
     * @return array Modified meta
     */
    public function add_plugin_meta($plugin_meta, $plugin_file) {
        if ($plugin_file === BASEO_SCHEMA_PLUGIN_BASENAME) {
            $plugin_meta[] = '<a href="' . $this->brand['support_url'] . '" target="_blank" style="color: ' . $this->brand['color'] . ';">🎯 ' . __('Premium Support', 'custom-schema-baseo') . '</a>';
            $plugin_meta[] = '<a href="' . $this->brand['author_url'] . '" target="_blank" style="color: ' . $this->brand['secondary_color'] . ';">🌟 ' . __('More BASEO Plugins', 'custom-schema-baseo') . '</a>';
            $plugin_meta[] = '<span style="color: #666;">' . sprintf(__('Made with ❤️ by %s', 'custom-schema-baseo'), $this->brand['name']) . '</span>';
        }
        return $plugin_meta;
    }
    
    /**
     * Add button to admin bar
     * 
     * @param WP_Admin_Bar $wp_admin_bar Admin bar object
     * @return void
     */
    public function add_admin_bar_button($wp_admin_bar) {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        $wp_admin_bar->add_node(array(
            'id' => 'baseo-custom-schema',
            'title' => '🚀 ' . __('Custom Schema', 'custom-schema-baseo'),
            'href' => admin_url('admin.php?page=baseo-custom-schema'),
            'meta' => array(
                'class' => 'baseo-admin-bar-button'
            )
        ));
    }
    
    /**
     * Show activation notice
     * 
     * @return void
     */
    public function show_activation_notice() {
        if (!get_transient('baseo_schema_activation_notice')) {
            return;
        }
        
        ?>
        <div class="notice notice-success is-dismissible">
            <p>
                <strong>🚀 <?php echo esc_html($this->brand['plugin_name']); ?></strong> 
                <?php _e('has been activated successfully!', 'custom-schema-baseo'); ?>
                <a href="<?php echo admin_url('admin.php?page=baseo-custom-schema'); ?>" class="button button-primary" style="margin-left: 10px;">
                    <?php _e('Get Started', 'custom-schema-baseo'); ?>
                </a>
            </p>
        </div>
        <?php
        
        delete_transient('baseo_schema_activation_notice');
    }
}