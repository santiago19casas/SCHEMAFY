<?php
/**
 * BASEO Schema Injector Class
 * 
 * Handles injection of schemas in the frontend wp_head
 * 
 * @package CustomSchemaBaseo
 * @since 1.1.85
 * @author BASEO Team
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit(__('Direct access not allowed!', 'custom-schema-baseo'));
}

/**
 * Class BASEO_Schema_Injector
 * 
 * Injects schema markup and meta tags in the frontend
 */
class BASEO_Schema_Injector {
    
    /**
     * SEO Detector instance
     * 
     * @var BASEO_SEO_Detector
     */
    private $seo_detector;
    
    /**
     * Validator instance
     * 
     * @var BASEO_Validator
     */
    private $validator;
    
    /**
     * Brand name
     * 
     * @var string
     */
    private $brand_name = 'BASEO';
    
    /**
     * Constructor
     * 
     * @param BASEO_SEO_Detector $seo_detector SEO detector instance
     * @param BASEO_Validator $validator Validator instance
     */
    public function __construct($seo_detector, $validator) {
        $this->seo_detector = $seo_detector;
        $this->validator = $validator;
    }
    
    /**
     * Inject schemas in wp_head
     * This is the main method called by WordPress wp_head hook
     * 
     * @return void
     */
    public function inject_schema() {
        $current_url = $this->get_current_url();
        $post_id = 0;
        
        if (is_singular()) {
            $post_id = get_the_ID();
        }
        
        // ==========================================
        // PASO 1: Get meta values
        // ==========================================
        $meta_title_value = $this->seo_detector->get_meta_title($post_id, $current_url);
        $meta_description_value = $this->seo_detector->get_meta_description($post_id, $current_url);
        
        // ==========================================
        // PASO 2: Get schemas for current URL
        // ==========================================
        global $wpdb;
        $table_name = $wpdb->prefix . 'baseo_custom_schemas';
        
        $schemas = $wpdb->get_results($wpdb->prepare(
            "SELECT schema_name, schema_data FROM $table_name 
             WHERE url = %s AND is_active = 1 
             ORDER BY created_at ASC",
            $current_url
        ));
        
        // ==========================================
        // PASO 3: Process and output schemas
        // ==========================================
        if ($schemas) {
            echo '<!-- Custom Schema by ' . esc_html($this->brand_name) . ' -->' . "\n";
            
            foreach ($schemas as $schema) {
                $schema_data = $schema->schema_data;
                
                // Replace {{meta_title}}
                if (!empty($meta_title_value)) {
                    $schema_data = str_replace('{{meta_title}}', addslashes($meta_title_value), $schema_data);
                } else {
                    $schema_data = str_replace('{{meta_title}}', '', $schema_data);
                }
                
                // Replace {{meta_description}}
                if (!empty($meta_description_value)) {
                    $schema_data = str_replace('{{meta_description}}', addslashes($meta_description_value), $schema_data);
                } else {
                    $schema_data = str_replace('{{meta_description}}', '', $schema_data);
                }
                
                // Validate JSON
                $decoded = json_decode($schema_data);
                if (json_last_error() !== JSON_ERROR_NONE) {
                    error_log('[BASEO Schema] Invalid JSON after variable replacement for schema: ' . $schema->schema_name);
                    continue;
                }
                
                // Output schema
                echo '<!-- Schema: ' . esc_html($schema->schema_name) . ' -->' . "\n";
                echo '<script type="application/ld+json">' . "\n";
                
                $json_output = wp_json_encode($decoded, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
                
                // Escape closing script tags to prevent breaking HTML
                $json_output = str_ireplace('</script>', '<\/script>', $json_output);
                
                echo $json_output . "\n";
                echo '</script>' . "\n";
            }
            
            echo '<!-- End Custom Schema by ' . esc_html($this->brand_name) . ' -->' . "\n";
        }
    }
    
    /**
     * Inject custom meta tags
     * This method can be called separately for meta tags injection
     * 
     * @return void
     */
    public function inject_meta_tags() {
        $current_url = $this->get_current_url();
        $post_id = 0;
        
        if (is_singular()) {
            $post_id = get_the_ID();
        }
        
        // Get meta values
        $meta_title = $this->seo_detector->get_meta_title($post_id, $current_url);
        $meta_description = $this->seo_detector->get_meta_description($post_id, $current_url);
        
        // If no meta from post, try table lookup
        if (empty($meta_title) && empty($meta_description)) {
            global $wpdb;
            $table_name = $wpdb->prefix . 'baseo_custom_schemas';
            
            $schema = $wpdb->get_row($wpdb->prepare(
                "SELECT meta_title, meta_description FROM $table_name 
                 WHERE url = %s AND is_active = 1 
                 ORDER BY updated_at DESC LIMIT 1",
                $current_url
            ));
            
            if ($schema) {
                $meta_title = $schema->meta_title;
                $meta_description = $schema->meta_description;
            }
        }
        
        // Inject meta tags if we have any
        if (!empty($meta_title) || !empty($meta_description)) {
            echo '<!-- Custom Meta Tags by ' . esc_html($this->brand_name) . ' -->' . "\n";
            
            if (!empty($meta_title)) {
                // Remove WordPress default title tag to replace it
                remove_action('wp_head', '_wp_render_title_tag', 1);
                
                // Inject custom title tag
                echo '<title>' . esc_html($meta_title) . '</title>' . "\n";
                
                // Social media meta tags
                echo '<meta property="og:title" content="' . esc_attr($meta_title) . '">' . "\n";
                echo '<meta name="twitter:title" content="' . esc_attr($meta_title) . '">' . "\n";
            }
            
            if (!empty($meta_description)) {
                echo '<meta name="description" content="' . esc_attr($meta_description) . '">' . "\n";
                echo '<meta property="og:description" content="' . esc_attr($meta_description) . '">' . "\n";
                echo '<meta name="twitter:description" content="' . esc_attr($meta_description) . '">' . "\n";
            }
            
            echo '<!-- End Custom Meta Tags by ' . esc_html($this->brand_name) . ' -->' . "\n";
        }
    }
    
    /**
     * Get current URL
     * 
     * @return string Current URL
     */
    private function get_current_url() {
        $protocol = is_ssl() ? 'https://' : 'http://';
        $url = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        
        // Canonize to HTTPS if site URL is HTTPS
        $site_url = get_site_url();
        if (strpos($site_url, 'https://') === 0 && strpos($url, 'http://') === 0) {
            $url = str_replace('http://', 'https://', $url);
        }
        
        return $url;
    }
    
    /**
     * Replace schema variables with actual values
     * 
     * @param string $schema_data Schema JSON string
     * @param string $meta_title Meta title value
     * @param string $meta_description Meta description value
     * @return string Processed schema data
     */
    public function replace_schema_variables($schema_data, $meta_title, $meta_description) {
        // Replace {{meta_title}}
        if (!empty($meta_title)) {
            $schema_data = str_replace('{{meta_title}}', addslashes($meta_title), $schema_data);
        } else {
            $schema_data = str_replace('{{meta_title}}', '', $schema_data);
        }
        
        // Replace {{meta_description}}
        if (!empty($meta_description)) {
            $schema_data = str_replace('{{meta_description}}', addslashes($meta_description), $schema_data);
        } else {
            $schema_data = str_replace('{{meta_description}}', '', $schema_data);
        }
        
        return $schema_data;
    }
    
    /**
     * Validate schema JSON before output
     * 
     * @param string $schema_data Schema JSON string
     * @return bool True if valid, false otherwise
     */
    public function validate_schema_json($schema_data) {
        $decoded = json_decode($schema_data);
        return json_last_error() === JSON_ERROR_NONE;
    }
    
    /**
     * Format JSON for output
     * 
     * @param mixed $data Decoded JSON data
     * @return string Formatted JSON string
     */
    public function format_json_output($data) {
        $json_output = wp_json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
        
        // Escape closing script tags to prevent breaking HTML
        $json_output = str_ireplace('</script>', '<\/script>', $json_output);
        
        return $json_output;
    }
}