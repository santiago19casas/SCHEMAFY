<?php
/**
 * BASEO Core Class
 * 
 * Main orchestrator that coordinates all plugin components
 * 
 * @package CustomSchemaBaseo
 * @since 1.1.85
 * @author BASEO Team
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit(__('Direct access not allowed!', 'custom-schema-baseo'));
}

/**
 * Class BASEO_Core
 * 
 * Main plugin class that orchestrates all components with dependency injection
 */
class BASEO_Core {
    
    /**
     * Component instances
     */
    private $validator;
    private $database;
    private $seo_detector;
    private $injector;
    private $rest_api;
    private $meta_box;
    private $admin;
    
    /**
     * Brand information
     * 
     * @var array
     */
    private $brand = array(
        'name' => 'BASEO',
        'plugin_name' => 'Custom Schema by BASEO',
        'plugin_url' => 'http://thebaseo.com/plugins',
        'author_url' => 'http://thebaseo.com',
        'support_url' => 'http://thebaseo.com/support',
        'docs_url' => 'http://thebaseo.com/docs/custom-schema',
        'color' => '#FF6B35',
        'secondary_color' => '#004E98'
    );
    
    /**
     * Constructor
     * Instantiates all classes with dependency injection
     */
    public function __construct() {
        // 1. Instantiate base classes (no dependencies)
        $this->validator = new BASEO_Validator();
        $this->database = new BASEO_Database();
        
        // 2. Instantiate classes with dependencies
        $this->seo_detector = new BASEO_SEO_Detector($this->validator);
        $this->injector = new BASEO_Schema_Injector($this->seo_detector, $this->validator);
        $this->rest_api = new BASEO_REST_API($this->validator, $this->database);
        $this->meta_box = new BASEO_Meta_Box($this->validator, $this->database);
        $this->admin = new BASEO_Admin($this->validator);
    }
    
    /**
     * Initialize plugin and register all hooks
     * This is the main entry point after construction
     * 
     * @return void
     */
    public function run() {
        // Load text domain
        add_action('plugins_loaded', array($this, 'load_textdomain'));
        
        // Frontend hooks
        add_action('wp_head', array($this->injector, 'inject_schema'), 5);
        add_action('wp_head', array($this->injector, 'inject_meta_tags'), 1);
        
        // Admin hooks
        add_action('admin_menu', array($this->admin, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this->admin, 'enqueue_admin_scripts'));
        add_action('admin_notices', array($this->admin, 'show_activation_notice'));
        add_action('admin_bar_menu', array($this->admin, 'add_admin_bar_button'), 100);
        
        // Plugin links
        add_filter('plugin_action_links_' . BASEO_SCHEMA_PLUGIN_BASENAME, array($this->admin, 'add_plugin_links'));
        add_filter('plugin_row_meta', array($this->admin, 'add_plugin_meta'), 10, 2);
        
        // REST API
        add_action('rest_api_init', array($this->rest_api, 'register_routes'));
        
        // Meta box is self-registering in its constructor
        // No need to add hooks here
        
        // Run database migrations if needed
        add_action('init', array($this, 'maybe_migrate_database'));
    }
    
    /**
     * Activation hook
     * Called when plugin is activated
     * 
     * @return void
     */
    public static function activate() {
        // Create database tables
        $database = new BASEO_Database();
        $database->create_tables();
        
        // Set activation notice transient
        set_transient('baseo_schema_activation_notice', true, 30);
        
        // Log activation
        error_log('[BASEO Schema] Plugin activated successfully');
    }
    
    /**
     * Deactivation hook
     * Called when plugin is deactivated
     * 
     * @return void
     */
    public static function deactivate() {
        // Clean up transients
        delete_transient('baseo_schema_activation_notice');
        
        // Log deactivation
        error_log('[BASEO Schema] Plugin deactivated');
    }
    
    /**
     * Load plugin text domain for translations
     * 
     * @return void
     */
    public function load_textdomain() {
        load_plugin_textdomain(
            'custom-schema-baseo',
            false,
            dirname(BASEO_SCHEMA_PLUGIN_BASENAME) . '/languages'
        );
    }
    
    /**
     * Maybe migrate database
     * Runs database migrations if needed
     * 
     * @return void
     */
    public function maybe_migrate_database() {
        $current_version = get_option('baseo_schema_db_version', '0');
        
        if (version_compare($current_version, BASEO_SCHEMA_VERSION, '<')) {
            $this->migrate_database();
            update_option('baseo_schema_db_version', BASEO_SCHEMA_VERSION);
        }
    }
    
    /**
     * Database migration
     * Adds new columns if they don't exist
     * 
     * @return void
     */
    private function migrate_database() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'baseo_custom_schemas';
        
        // Check if table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") !== $table_name) {
            // Table doesn't exist, create it
            $this->database->create_tables();
            return;
        }
        
        // Check if columns exist
        $columns = $wpdb->get_col("DESCRIBE $table_name");
        
        // Add meta_title column if it doesn't exist
        if (!in_array('meta_title', $columns)) {
            $wpdb->query("ALTER TABLE $table_name ADD COLUMN meta_title TEXT AFTER schema_data");
            error_log('[BASEO Schema] Added meta_title column to database');
        }
        
        // Add meta_description column if it doesn't exist
        if (!in_array('meta_description', $columns)) {
            $wpdb->query("ALTER TABLE $table_name ADD COLUMN meta_description TEXT AFTER meta_title");
            error_log('[BASEO Schema] Added meta_description column to database');
        }
        
        // Add is_active column if it doesn't exist
        if (!in_array('is_active', $columns)) {
            $wpdb->query("ALTER TABLE $table_name ADD COLUMN is_active TINYINT(1) DEFAULT 1 AFTER meta_description");
            error_log('[BASEO Schema] Added is_active column to database');
        }
        
        // Add created_at column if it doesn't exist
        if (!in_array('created_at', $columns)) {
            $wpdb->query("ALTER TABLE $table_name ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP AFTER is_active");
            error_log('[BASEO Schema] Added created_at column to database');
        }
        
        // Add updated_at column if it doesn't exist
        if (!in_array('updated_at', $columns)) {
            $wpdb->query("ALTER TABLE $table_name ADD COLUMN updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at");
            error_log('[BASEO Schema] Added updated_at column to database');
        }
    }
    
    /**
     * Get brand information
     * 
     * @return array Brand information array
     */
    public function get_brand() {
        return $this->brand;
    }
    
    /**
     * Get validator instance
     * 
     * @return BASEO_Validator
     */
    public function get_validator() {
        return $this->validator;
    }
    
    /**
     * Get database instance
     * 
     * @return BASEO_Database
     */
    public function get_database() {
        return $this->database;
    }
    
    /**
     * Get SEO detector instance
     * 
     * @return BASEO_SEO_Detector
     */
    public function get_seo_detector() {
        return $this->seo_detector;
    }
    
    /**
     * Get injector instance
     * 
     * @return BASEO_Schema_Injector
     */
    public function get_injector() {
        return $this->injector;
    }
    
    /**
     * Get REST API instance
     * 
     * @return BASEO_REST_API
     */
    public function get_rest_api() {
        return $this->rest_api;
    }
    
    /**
     * Get meta box instance
     * 
     * @return BASEO_Meta_Box
     */
    public function get_meta_box() {
        return $this->meta_box;
    }
    
    /**
     * Get admin instance
     * 
     * @return BASEO_Admin
     */
    public function get_admin() {
        return $this->admin;
    }
}