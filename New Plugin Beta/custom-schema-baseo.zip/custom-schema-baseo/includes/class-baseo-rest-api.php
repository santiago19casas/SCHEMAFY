<?php
/**
 * BASEO REST API Class
 * 
 * Handles all REST API endpoints for the Custom Schema by BASEO plugin
 * 
 * @package CustomSchemaBaseo
 * @since 1.1.85
 * @author BASEO Team
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit(__('Direct access not allowed!', 'custom-schema-baseo'));
}

/**
 * Class BASEO_REST_API
 * 
 * Manages all REST API endpoints for schema operations
 */
class BASEO_REST_API {
    
    /**
     * Validator instance
     * 
     * @var BASEO_Validator
     */
    private $validator;
    
    /**
     * Database instance
     * 
     * @var BASEO_Database
     */
    private $database;
    
    /**
     * API namespace
     * 
     * @var string
     */
    private $namespace = 'baseo/v1';
    
    /**
     * Constructor
     * 
     * @param BASEO_Validator $validator Validator instance
     * @param BASEO_Database $database Database instance
     */
    public function __construct($validator, $database) {
        $this->validator = $validator;
        $this->database = $database;
    }
    
    /**
     * Register REST API routes
     * Called by WordPress rest_api_init hook
     * 
     * @return void
     */
    public function register_routes() {
        // List and create schemas
        register_rest_route($this->namespace, '/schemas', array(
            array(
                'methods' => 'GET',
                'callback' => array($this, 'get_schemas'),
                'permission_callback' => array($this, 'permission_check')
            ),
            array(
                'methods' => 'POST',
                'callback' => array($this, 'create_schema'),
                'permission_callback' => array($this, 'permission_check')
            )
        ));
        
        // Get, update, and delete specific schema
        register_rest_route($this->namespace, '/schemas/(?P<id>\d+)', array(
            array(
                'methods' => 'GET',
                'callback' => array($this, 'get_schema'),
                'permission_callback' => array($this, 'permission_check')
            ),
            array(
                'methods' => 'PUT',
                'callback' => array($this, 'update_schema'),
                'permission_callback' => array($this, 'permission_check')
            ),
            array(
                'methods' => 'DELETE',
                'callback' => array($this, 'delete_schema'),
                'permission_callback' => array($this, 'permission_check')
            )
        ));
        
        // Toggle schema active/inactive status
        register_rest_route($this->namespace, '/schemas/(?P<id>\d+)/toggle', array(
            'methods' => 'POST',
            'callback' => array($this, 'toggle_schema'),
            'permission_callback' => array($this, 'permission_check')
        ));
        
        // Bulk apply schemas to multiple URLs
        register_rest_route($this->namespace, '/schemas/bulk-apply', array(
            'methods' => 'POST',
            'callback' => array($this, 'bulk_apply_schemas'),
            'permission_callback' => array($this, 'permission_check')
        ));
    }
    
    /**
     * Permission check for REST API endpoints
     * 
     * @param WP_REST_Request $request Request object
     * @return bool True if user has permission, false otherwise
     */
    public function permission_check($request) {
        return $this->validator->validate_user_capability('manage_options');
    }
    
    /**
     * GET /schemas - Get all schemas with pagination and filters
     * 
     * @param WP_REST_Request $request Request object
     * @return WP_REST_Response|WP_Error Response or error
     */
    public function get_schemas($request) {
        // Get and sanitize query parameters
        $page = max(1, intval($request->get_param('page') ?? 1));
        $per_page = min(100, max(1, intval($request->get_param('per_page') ?? 20)));
        $url_filter = $request->get_param('url');
        $type_filter = $request->get_param('schema_type');
        $search_filter = $request->get_param('search');
        
        // Sanitize pagination
        $pagination = $this->validator->sanitize_pagination($page, $per_page);
        
        // Validate schema_type if provided
        if ($type_filter !== null) {
            if (!$this->validator->is_valid_schema_type($type_filter)) {
                return new WP_Error('invalid_type', __('Invalid schema type', 'custom-schema-baseo'), array('status' => 400));
            }
            $type_filter = sanitize_text_field($type_filter);
        }
        
        // Sanitize URL if provided
        if ($url_filter !== null) {
            $url_filter = $this->validator->sanitize_url($url_filter);
        }
        
        // Sanitize search if provided
        if ($search_filter !== null) {
            $search_filter = $this->validator->sanitize_search_query($search_filter);
        }
        
        // Get schemas from database
        $result = $this->database->get_schemas(array(
            'page' => $pagination['page'],
            'per_page' => $pagination['per_page'],
            'url' => $url_filter,
            'schema_type' => $type_filter,
            'search' => $search_filter
        ));
        
        // Convert objects to arrays for REST response
        $items = array();
        foreach ($result['items'] as $item) {
            $items[] = (array) $item;
        }
        
        // Create response with pagination headers
        $response = new WP_REST_Response($items);
        
        $response->header('X-WP-Total', $result['total']);
        $response->header('X-WP-TotalPages', $result['pages']);
        $response->header('X-WP-Page', $result['current_page']);
        $response->header('X-WP-Per-Page', $result['per_page']);
        
        // Build Link headers for pagination
        $links = array();
        
        // Self link
        $self_params = array_filter(array(
            'page' => $result['current_page'],
            'per_page' => $result['per_page'],
            'schema_type' => $type_filter,
            'url' => $url_filter,
            'search' => $search_filter
        ));
        $self_url = rest_url($this->namespace . '/schemas') . '?' . http_build_query($self_params, '', '&', PHP_QUERY_RFC3986);
        $links[] = '<' . $self_url . '>; rel="self"';
        
        // First page link
        if ($result['current_page'] > 1) {
            $first_params = array_filter(array(
                'page' => 1,
                'per_page' => $result['per_page'],
                'schema_type' => $type_filter,
                'url' => $url_filter,
                'search' => $search_filter
            ));
            $first_url = rest_url($this->namespace . '/schemas') . '?' . http_build_query($first_params, '', '&', PHP_QUERY_RFC3986);
            $links[] = '<' . $first_url . '>; rel="first"';
        }
        
        // Previous page link
        if ($result['current_page'] > 1) {
            $prev_params = array_filter(array(
                'page' => $result['current_page'] - 1,
                'per_page' => $result['per_page'],
                'schema_type' => $type_filter,
                'url' => $url_filter,
                'search' => $search_filter
            ));
            $prev_url = rest_url($this->namespace . '/schemas') . '?' . http_build_query($prev_params, '', '&', PHP_QUERY_RFC3986);
            $links[] = '<' . $prev_url . '>; rel="prev"';
        }
        
        // Next page link
        if ($result['current_page'] < $result['pages']) {
            $next_params = array_filter(array(
                'page' => $result['current_page'] + 1,
                'per_page' => $result['per_page'],
                'schema_type' => $type_filter,
                'url' => $url_filter,
                'search' => $search_filter
            ));
            $next_url = rest_url($this->namespace . '/schemas') . '?' . http_build_query($next_params, '', '&', PHP_QUERY_RFC3986);
            $links[] = '<' . $next_url . '>; rel="next"';
        }
        
        // Last page link
        if ($result['current_page'] < $result['pages'] && $result['pages'] > 1) {
            $last_params = array_filter(array(
                'page' => $result['pages'],
                'per_page' => $result['per_page'],
                'schema_type' => $type_filter,
                'url' => $url_filter,
                'search' => $search_filter
            ));
            $last_url = rest_url($this->namespace . '/schemas') . '?' . http_build_query($last_params, '', '&', PHP_QUERY_RFC3986);
            $links[] = '<' . $last_url . '>; rel="last"';
        }
        
        // Set Link header if we have links
        if (!empty($links)) {
            $response->header('Link', implode(', ', $links));
        }
        
        return $response;
    }
    
    /**
     * GET /schemas/{id} - Get single schema
     * 
     * @param WP_REST_Request $request Request object
     * @return WP_REST_Response|WP_Error Response or error
     */
    public function get_schema($request) {
        $id = $this->validator->sanitize_id($request['id']);
        
        $schema = $this->database->get_schema($id);
        
        if (!$schema) {
            return new WP_Error('not_found', __('Schema not found', 'custom-schema-baseo'), array('status' => 404));
        }
        
        return rest_ensure_response((array) $schema);
    }
    
    /**
     * POST /schemas - Create new schema
     * 
     * @param WP_REST_Request $request Request object
     * @return WP_REST_Response|WP_Error Response or error
     */
    public function create_schema($request) {
        $params = $request->get_json_params();
        
        // Sanitize data
        $data = array(
            'url' => $this->validator->sanitize_url($params['url'] ?? ''),
            'schema_type' => sanitize_text_field($params['schema_type'] ?? 'WebPage'),
            'schema_name' => $this->validator->sanitize_schema_name($params['schema_name'] ?? __('Schema without name', 'custom-schema-baseo')),
            'schema_data' => wp_unslash($params['schema_data'] ?? ''),
            'meta_title' => isset($params['meta_title']) ? sanitize_text_field($params['meta_title']) : '',
            'meta_description' => isset($params['meta_description']) ? sanitize_textarea_field($params['meta_description']) : '',
            'is_active' => isset($params['is_active']) ? intval($params['is_active']) : 1
        );
        
        // Canonize URL to HTTPS
        $data['url'] = $this->canonize_url_https($data['url']);
        
        // Validate data
        $validation = $this->validator->validate_schema_create_data($data);
        if (is_wp_error($validation)) {
            return $validation;
        }
        
        // Create schema
        $id = $this->database->create_schema($data);
        
        if ($id === false) {
            return new WP_Error('db_error', __('Error saving schema', 'custom-schema-baseo'), array('status' => 500));
        }
        
        return rest_ensure_response(array('id' => $id, 'success' => true));
    }
    
    /**
     * PUT /schemas/{id} - Update existing schema
     * 
     * @param WP_REST_Request $request Request object
     * @return WP_REST_Response|WP_Error Response or error
     */
    public function update_schema($request) {
        $id = $this->validator->sanitize_id($request['id']);
        $params = $request->get_json_params();
        
        // Check if schema exists
        if (!$this->database->schema_exists($id)) {
            return new WP_Error('not_found', __('Schema not found', 'custom-schema-baseo'), array('status' => 404));
        }
        
        // Sanitize data
        $data = array(
            'url' => $this->validator->sanitize_url($params['url'] ?? ''),
            'schema_type' => sanitize_text_field($params['schema_type'] ?? 'WebPage'),
            'schema_name' => $this->validator->sanitize_schema_name($params['schema_name'] ?? __('Schema without name', 'custom-schema-baseo')),
            'schema_data' => wp_unslash($params['schema_data'] ?? ''),
            'meta_title' => isset($params['meta_title']) ? sanitize_text_field($params['meta_title']) : '',
            'meta_description' => isset($params['meta_description']) ? sanitize_textarea_field($params['meta_description']) : ''
        );
        
        // Canonize URL to HTTPS
        $data['url'] = $this->canonize_url_https($data['url']);
        
        // Validate data
        $validation = $this->validator->validate_schema_update_data($data, false);
        if (is_wp_error($validation)) {
            return $validation;
        }
        
        // Update schema
        $result = $this->database->update_schema($id, $data);
        
        if ($result === false) {
            return new WP_Error('db_error', __('Error updating schema', 'custom-schema-baseo'), array('status' => 500));
        }
        
        return rest_ensure_response(array('success' => true));
    }
    
    /**
     * DELETE /schemas/{id} - Delete schema
     * 
     * @param WP_REST_Request $request Request object
     * @return WP_REST_Response|WP_Error Response or error
     */
    public function delete_schema($request) {
        $id = $this->validator->sanitize_id($request['id']);
        
        // Check if schema exists
        if (!$this->database->schema_exists($id)) {
            return new WP_Error('not_found', __('Schema not found', 'custom-schema-baseo'), array('status' => 404));
        }
        
        // Delete schema
        $result = $this->database->delete_schema($id);
        
        if ($result === false) {
            return new WP_Error('db_error', __('Error deleting schema', 'custom-schema-baseo'), array('status' => 500));
        }
        
        return rest_ensure_response(array('success' => true));
    }
    
    /**
     * POST /schemas/{id}/toggle - Toggle schema active status
     * 
     * @param WP_REST_Request $request Request object
     * @return WP_REST_Response|WP_Error Response or error
     */
    public function toggle_schema($request) {
        $id = $this->validator->sanitize_id($request['id']);
        
        // Check if schema exists
        if (!$this->database->schema_exists($id)) {
            return new WP_Error('not_found', __('Schema not found', 'custom-schema-baseo'), array('status' => 404));
        }
        
        // Toggle status
        $new_status = $this->database->toggle_schema($id);
        
        if ($new_status === false) {
            return new WP_Error('db_error', __('Error updating status', 'custom-schema-baseo'), array('status' => 500));
        }
        
        return rest_ensure_response(array('is_active' => $new_status));
    }
    
    /**
     * POST /schemas/bulk-apply - Bulk apply schema to multiple URLs
     * 
     * @param WP_REST_Request $request Request object
     * @return WP_REST_Response|WP_Error Response or error
     */
    public function bulk_apply_schemas($request) {
        $params = $request->get_json_params();
        
        // Validate bulk data
        $validation = $this->validator->validate_bulk_apply_data($params);
        if (is_wp_error($validation)) {
            return $validation;
        }
        
        // Prepare base data
        $schema_name = $this->validator->sanitize_schema_name($params['schema_name'] ?? __('Bulk Schema', 'custom-schema-baseo'));
        $schema_type = sanitize_text_field($params['schema_type'] ?? 'WebPage');
        $schema_data = wp_unslash($params['schema_data'] ?? '');
        $meta_title = isset($params['meta_title']) ? sanitize_text_field($params['meta_title']) : '';
        $meta_description = isset($params['meta_description']) ? sanitize_textarea_field($params['meta_description']) : '';
        
        // Build schemas array
        $schemas = array();
        foreach ($params['urls'] as $url) {
            $url = $this->validator->sanitize_url($url);
            $url = $this->canonize_url_https($url);
            
            $schemas[] = array(
                'url' => $url,
                'schema_name' => $schema_name,
                'schema_data' => $schema_data,
                'schema_type' => $schema_type,
                'meta_title' => $meta_title,
                'meta_description' => $meta_description,
                'is_active' => 1
            );
        }
        
        // Bulk create
        $results = $this->database->bulk_create_schemas($schemas);
        
        return rest_ensure_response(array(
            'success' => $results['success'],
            'failed' => $results['failed'],
            'errors' => $results['errors']
        ));
    }
    
    /**
     * Canonize URL to HTTPS if site uses HTTPS
     * 
     * @param string $url URL to canonize
     * @return string Canonized URL
     */
    private function canonize_url_https($url) {
        $site_parsed = wp_parse_url(home_url());
        $input_parsed = wp_parse_url($url);
        
        if (!$input_parsed || !isset($input_parsed['host'])) {
            return $url;
        }
        
        // Detect if home_url() uses HTTPS
        $site_is_https = ($site_parsed['scheme'] === 'https');
        
        // Detect if it's development environment
        $input_host = strtolower($input_parsed['host']);
        $is_dev_host = (
            $input_host === 'localhost' ||
            $input_host === '127.0.0.1' ||
            (substr_compare($input_host, '.test', -5) === 0) ||
            (substr_compare($input_host, '.local', -6) === 0)
        );
        
        // Canonize to HTTPS if site is HTTPS and NOT development
        if ($site_is_https && !$is_dev_host && $input_parsed['scheme'] === 'http') {
            // Rebuild URL with HTTPS maintaining host/path/query/fragment
            $url = 'https://' . $input_parsed['host'];
            if (isset($input_parsed['path'])) $url .= $input_parsed['path'];
            if (isset($input_parsed['query'])) $url .= '?' . $input_parsed['query'];
            if (isset($input_parsed['fragment'])) $url .= '#' . $input_parsed['fragment'];
        }
        
        return $url;
    }
}