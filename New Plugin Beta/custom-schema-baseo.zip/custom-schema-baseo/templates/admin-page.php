<?php
/**
 * Admin Page Template
 * 
 * Main admin interface for Custom Schema by BASEO
 * 
 * @package CustomSchemaBaseo
 * @since 1.1.85
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap baseo-admin-wrap">
    <div class="baseo-header">
        <div class="baseo-header-content">
            <h1>
                <span class="dashicons dashicons-code-standards"></span>
                <?php _e('Custom Schema by BASEO', 'custom-schema-baseo'); ?>
            </h1>
            <p class="baseo-subtitle">
                <?php _e('Professional schema.org markup for maximum SEO impact', 'custom-schema-baseo'); ?>
            </p>
        </div>
        <div class="baseo-header-actions">
            <a href="http://thebaseo.com/docs/custom-schema" target="_blank" class="baseo-btn baseo-btn-secondary">
                <?php _e('📖 Documentation', 'custom-schema-baseo'); ?>
            </a>
            <a href="http://thebaseo.com/support" target="_blank" class="baseo-btn baseo-btn-secondary">
                <?php _e('💬 Support', 'custom-schema-baseo'); ?>
            </a>
        </div>
    </div>

    <div class="baseo-tabs">
        <button class="baseo-tab-btn active" data-tab="single">
            <?php _e('➕ Single Schema', 'custom-schema-baseo'); ?>
        </button>
        <button class="baseo-tab-btn" data-tab="bulk">
            <?php _e('📋 Bulk Schemas', 'custom-schema-baseo'); ?>
        </button>
    </div>

    <!-- Single Schema Tab -->
    <div id="baseo-tab-single" class="baseo-tab-content active">
        <div class="baseo-card">
            <h2><?php _e('Add New Schema', 'custom-schema-baseo'); ?></h2>
            
            <form id="baseo-schema-form" method="post">
                <!-- URL Field -->
                <div class="baseo-form-group">
                    <label for="baseo-url">
                        <?php _e('URL', 'custom-schema-baseo'); ?> <span class="required">*</span>
                    </label>
                    <input 
                        type="url" 
                        id="baseo-url" 
                        name="url" 
                        required
                        placeholder="https://<?php echo $_SERVER['HTTP_HOST']; ?>/your-page/"
                    >
                    <p class="baseo-help-text">
                        <?php _e('Enter the complete URL where this schema will appear', 'custom-schema-baseo'); ?>
                    </p>
                </div>

                <!-- Schema Name -->
                <div class="baseo-form-group">
                    <label for="baseo-schema-name">
                        <?php _e('Schema Name', 'custom-schema-baseo'); ?> <span class="required">*</span>
                    </label>
                    <input 
                        type="text" 
                        id="baseo-schema-name" 
                        name="schema_name" 
                        required
                        placeholder="<?php _e('e.g., Homepage Organization Schema', 'custom-schema-baseo'); ?>"
                    >
                </div>

                <!-- Schema Type -->
                <div class="baseo-form-group">
                    <label for="baseo-schema-type">
                        <?php _e('Schema Type', 'custom-schema-baseo'); ?> <span class="required">*</span>
                    </label>
                    <select id="baseo-schema-type" name="schema_type" required>
                        <option value=""><?php _e('Select type...', 'custom-schema-baseo'); ?></option>
                        <option value="WebPage">📄 WebPage</option>
                        <option value="Article">📰 Article</option>
                        <option value="Product">🛍️ Product</option>
                        <option value="Organization">🏢 Organization</option>
                        <option value="LocalBusiness">🏪 LocalBusiness</option>
                        <option value="Person">👤 Person</option>
                        <option value="Event">🎉 Event</option>
                        <option value="Recipe">🍳 Recipe</option>
                        <option value="Review">⭐ Review</option>
                        <option value="FAQ">❓ FAQ</option>
                        <option value="Custom">⚙️ Custom</option>
                    </select>
                </div>

                <!-- Schema Data -->
                <div class="baseo-form-group">
                    <label for="baseo-schema-editor">
                        <?php _e('JSON-LD Code', 'custom-schema-baseo'); ?> <span class="required">*</span>
                    </label>
                    
                    <div class="baseo-editor-toolbar">
                        <button type="button" class="baseo-btn-micro" id="baseo-add-meta-title">
                            <?php _e('➕ {{meta_title}}', 'custom-schema-baseo'); ?>
                        </button>
                        <button type="button" class="baseo-btn-micro" id="baseo-add-meta-description">
                            <?php _e('➕ {{meta_description}}', 'custom-schema-baseo'); ?>
                        </button>
                        <button type="button" class="baseo-btn-micro" id="baseo-format-json">
                            <?php _e('✨ Format', 'custom-schema-baseo'); ?>
                        </button>
                        <button type="button" class="baseo-btn-micro" id="baseo-validate-json">
                            <?php _e('✅ Validate', 'custom-schema-baseo'); ?>
                        </button>
                    </div>
                    
                    <div 
                        id="baseo-schema-editor" 
                        class="baseo-editor" 
                        contenteditable="true"
                        data-placeholder='{"@context": "https://schema.org", "@type": "Organization", "name": "Your Company"}'
                    ></div>
                    
                    <textarea 
                        id="baseo-schema-data" 
                        name="schema_data" 
                        style="display: none;" 
                        required
                    ></textarea>
                    
                    <p class="baseo-help-text">
                        <?php _e('Paste your JSON-LD schema code here. You can use {{meta_title}} and {{meta_description}} variables.', 'custom-schema-baseo'); ?>
                    </p>
                </div>

                <!-- Meta Title (Optional) -->
                <div class="baseo-form-group">
                    <label for="baseo-meta-title">
                        <?php _e('Meta Title (Optional)', 'custom-schema-baseo'); ?>
                    </label>
                    <input 
                        type="text" 
                        id="baseo-meta-title" 
                        name="meta_title"
                        maxlength="70"
                        placeholder="<?php _e('Leave empty to use SEO plugin value', 'custom-schema-baseo'); ?>"
                    >
                    <div id="baseo-meta-title-counter" class="baseo-char-counter">
                        <span class="baseo-char-count">0</span> / <span class="baseo-char-limit">70</span>
                        <span class="baseo-char-remaining"><?php _e('70 characters left', 'custom-schema-baseo'); ?></span>
                    </div>
                </div>

                <!-- Meta Description (Optional) -->
                <div class="baseo-form-group">
                    <label for="baseo-meta-description">
                        <?php _e('Meta Description (Optional)', 'custom-schema-baseo'); ?>
                    </label>
                    <textarea 
                        id="baseo-meta-description" 
                        name="meta_description"
                        rows="3"
                        maxlength="160"
                        placeholder="<?php _e('Leave empty to use SEO plugin value', 'custom-schema-baseo'); ?>"
                    ></textarea>
                    <div id="baseo-meta-description-counter" class="baseo-char-counter">
                        <span class="baseo-char-count">0</span> / <span class="baseo-char-limit">160</span>
                        <span class="baseo-char-remaining"><?php _e('160 characters left', 'custom-schema-baseo'); ?></span>
                    </div>
                </div>

                <!-- Active Status -->
                <div class="baseo-form-group">
                    <label>
                        <input 
                            type="checkbox" 
                            id="baseo-is-active" 
                            name="is_active" 
                            value="1"
                            checked
                        >
                        <?php _e('Active (will be displayed on the page)', 'custom-schema-baseo'); ?>
                    </label>
                </div>

                <!-- Submit Button -->
                <div class="baseo-form-actions">
                    <button type="submit" class="baseo-btn baseo-btn-primary">
                        <?php _e('💾 Save Schema', 'custom-schema-baseo'); ?>
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Bulk Schemas Tab -->
    <div id="baseo-tab-bulk" class="baseo-tab-content">
        <div class="baseo-card">
            <div class="baseo-card-header">
                <h2><?php _e('Manage Schemas', 'custom-schema-baseo'); ?></h2>
                
                <div class="baseo-filters">
                    <select id="baseo-filter-type" class="baseo-select">
                        <option value=""><?php _e('All Types', 'custom-schema-baseo'); ?></option>
                        <option value="WebPage">📄 WebPage</option>
                        <option value="Article">📰 Article</option>
                        <option value="Product">🛍️ Product</option>
                        <option value="Organization">🏢 Organization</option>
                        <option value="LocalBusiness">🏪 LocalBusiness</option>
                        <option value="Person">👤 Person</option>
                        <option value="Event">🎉 Event</option>
                        <option value="Recipe">🍳 Recipe</option>
                        <option value="Review">⭐ Review</option>
                        <option value="FAQ">❓ FAQ</option>
                        <option value="Custom">⚙️ Custom</option>
                    </select>
                    
                    <input 
                        type="search" 
                        id="baseo-search" 
                        class="baseo-search-input"
                        placeholder="<?php _e('Search schemas...', 'custom-schema-baseo'); ?>"
                    >
                    
                    <select id="baseo-filter-perpage" class="baseo-select">
                        <option value="10">10 <?php _e('per page', 'custom-schema-baseo'); ?></option>
                        <option value="20" selected>20 <?php _e('per page', 'custom-schema-baseo'); ?></option>
                        <option value="50">50 <?php _e('per page', 'custom-schema-baseo'); ?></option>
                        <option value="100">100 <?php _e('per page', 'custom-schema-baseo'); ?></option>
                    </select>
                </div>
            </div>
            
            <div id="baseo-schemas-container">
                <div class="baseo-loading">
                    <div class="baseo-spinner"></div>
                    <p><?php _e('Loading schemas...', 'custom-schema-baseo'); ?></p>
                </div>
            </div>
        </div>
    </div>

    <div class="baseo-footer">
        <p>
            <?php _e('Made with ❤️ by', 'custom-schema-baseo'); ?> 
            <a href="http://thebaseo.com" target="_blank"><strong>BASEO</strong></a>
        </p>
    </div>
</div>