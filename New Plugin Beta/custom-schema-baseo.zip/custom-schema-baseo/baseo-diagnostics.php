<?php
/**
 * BASEO Schema Diagnostics
 * 
 * Add this to your functions.php temporarily to diagnose API issues
 * Remove after fixing the issue
 */

add_action('admin_notices', 'baseo_diagnostics_notice');

function baseo_diagnostics_notice() {
    if (!current_user_can('manage_options')) {
        return;
    }
    
    echo '<div class="notice notice-info"><p><strong>BASEO Diagnostics:</strong></p>';
    
    // 1. Check if plugin is loaded
    if (class_exists('BASEO_Core')) {
        echo '<p>✅ BASEO_Core class exists</p>';
    } else {
        echo '<p>❌ BASEO_Core class NOT found - Plugin not loaded correctly!</p>';
    }
    
    // 2. Check if REST API class exists
    if (class_exists('BASEO_REST_API')) {
        echo '<p>✅ BASEO_REST_API class exists</p>';
    } else {
        echo '<p>❌ BASEO_REST_API class NOT found!</p>';
    }
    
    // 3. Check database table
    global $wpdb;
    $table_name = $wpdb->prefix . 'baseo_custom_schemas';
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_name'") === $table_name;
    
    if ($table_exists) {
        $count = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
        echo '<p>✅ Database table exists with ' . $count . ' schemas</p>';
    } else {
        echo '<p>❌ Database table NOT found!</p>';
    }
    
    // 4. Check REST API endpoints
    $rest_url = rest_url('baseo/v1/schemas');
    echo '<p>📍 REST URL: <code>' . esc_html($rest_url) . '</code></p>';
    
    // 5. Test REST API availability
    $response = wp_remote_get($rest_url, array(
        'headers' => array(
            'X-WP-Nonce' => wp_create_nonce('wp_rest')
        )
    ));
    
    if (is_wp_error($response)) {
        echo '<p>❌ REST API Error: ' . esc_html($response->get_error_message()) . '</p>';
    } else {
        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        echo '<p>REST API Response Code: <strong>' . $code . '</strong></p>';
        
        if ($code === 200) {
            echo '<p>✅ REST API is working!</p>';
            $data = json_decode($body, true);
            if (is_array($data)) {
                echo '<p>Found ' . count($data) . ' schemas via REST API</p>';
            }
        } else {
            echo '<p>❌ REST API returned error code: ' . $code . '</p>';
            echo '<p>Response: <code>' . esc_html(substr($body, 0, 500)) . '</code></p>';
        }
    }
    
    // 6. Check JavaScript localization
    echo '<p>Check browser console for <code>baseo_ajax</code> object</p>';
    
    echo '</div>';
}

// Add a test endpoint
add_action('rest_api_init', function() {
    register_rest_route('baseo-test/v1', '/ping', array(
        'methods' => 'GET',
        'callback' => function() {
            return array(
                'status' => 'ok',
                'message' => 'BASEO REST API is reachable',
                'time' => current_time('mysql')
            );
        },
        'permission_callback' => '__return_true'
    ));
});