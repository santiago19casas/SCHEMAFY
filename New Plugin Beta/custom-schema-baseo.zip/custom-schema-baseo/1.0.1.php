<?php
/**
 * Plugin Name: Custom Schema by BASEO
 * Plugin URI: http://thebaseo.com/plugins
 * Description: 🚀 Professional plugin to add custom schema to each URL of your website. Developed by BASEO to maximize your SEO.
 * Version: 1.1.85
 * Author: BASEO
 * Author URI: http://thebaseo.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: custom-schema-baseo
 * Domain Path: /languages
 * Requires at least: 5.0
 * Tested up to: 6.3
 * Requires PHP: 7.4
 * Network: false
 * 
 * @package CustomSchemaBaseo
 * @author BASEO Team
 * @since 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit(__('Direct access not allowed!', 'custom-schema-baseo'));
}

// Define plugin constants
define('BASEO_SCHEMA_VERSION', '1.1.85');
define('BASEO_SCHEMA_PLUGIN_URL', plugin_dir_url(__FILE__));
define('BASEO_SCHEMA_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('BASEO_SCHEMA_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Require class files
require_once BASEO_SCHEMA_PLUGIN_PATH . 'includes/class-baseo-validator.php';
require_once BASEO_SCHEMA_PLUGIN_PATH . 'includes/class-baseo-database.php';
require_once BASEO_SCHEMA_PLUGIN_PATH . 'includes/class-baseo-seo-detector.php';
require_once BASEO_SCHEMA_PLUGIN_PATH . 'includes/class-baseo-schema-injector.php';
require_once BASEO_SCHEMA_PLUGIN_PATH . 'includes/class-baseo-rest-api.php';
require_once BASEO_SCHEMA_PLUGIN_PATH . 'includes/class-baseo-meta-box.php';
require_once BASEO_SCHEMA_PLUGIN_PATH . 'includes/class-baseo-admin.php';
require_once BASEO_SCHEMA_PLUGIN_PATH . 'includes/class-baseo-core.php';

// Activation/Deactivation hooks
register_activation_hook(__FILE__, array('BASEO_Core', 'activate'));
register_deactivation_hook(__FILE__, array('BASEO_Core', 'deactivate'));

/**
 * Initialize plugin
 * Creates and runs the main BASEO_Core instance
 * 
 * @return void
 */
function baseo_schema_init() {
    $baseo = new BASEO_Core();
    $baseo->run();
}

// Initialize plugin on plugins_loaded hook
add_action('plugins_loaded', 'baseo_schema_init');

/**
 * Log plugin loaded
 */
if (defined('WP_DEBUG') && WP_DEBUG) {
    error_log('[BASEO Schema] Plugin loaded successfully - Version ' . BASEO_SCHEMA_VERSION);
}